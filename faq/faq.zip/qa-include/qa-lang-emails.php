<?php
/**
 * @deprecated This file is deprecated from Q2A 1.7; use the below file instead.
 */

return (include QA_INCLUDE_DIR.'lang/qa-lang-emails.php');
